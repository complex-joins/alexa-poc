// Create a copy of this file called config.js and put your API keys there
module.exports = {
  PROD: true
};
